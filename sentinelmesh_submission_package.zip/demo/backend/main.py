from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import uuid, json

app = FastAPI(title="SentinelMesh Demo API")

class IngestRequest(BaseModel):
    user_id: str
    content: str
    metadata: dict = {}

@app.post("/api/v1/ingest")
def ingest(req: IngestRequest):
    trace_id = str(uuid.uuid4())
    score = 0.84 if "money" in req.content.lower() or "transfer" in req.content.lower() else 0.12
    result = {
        "trace_id": trace_id,
        "detection_score": score,
        "flags": ["request_for_money"] if score>0.5 else [],
        "rationale": ["Contains request for funds", "Rapid intimacy language"] if score>0.5 else ["Low risk signals"],
        "report_url": f"/api/v1/report/{trace_id}"
    }
    return result

@app.get("/api/v1/report/{trace_id}")
def report(trace_id: str):
    return {"trace_id": trace_id, "report": "This is a demo report. Replace with PDF generation in production."}
