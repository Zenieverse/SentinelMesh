# SentinelMesh — Agentic AI for Real-Time Cyber Fraud Defense

**Project:** SentinelMesh
**Hackathon:** AWS Global Vibe: AI Coding Hackathon 2025
**Tracks:** Agentic AI Systems, AI Cybersecurity & Privacy, AI-Enhanced Finance

---

## Elevator Pitch
SentinelMesh is an agentic AI defense system that detects, explains, and packages evidence for social-engineering fraud (e.g., romance scams, phishing, deepfake voice fraud) in real-time. It uses a multi-agent pipeline to ingest suspect content, detect fraudulent signals, extract forensics, and notify users or organizations with actionable evidence. Built and prototyped using **Amazon Q Developer** and **Amazon Kiro**, SentinelMesh showcases spec-driven agents, auto-generated code, and rapid iteration.

---
