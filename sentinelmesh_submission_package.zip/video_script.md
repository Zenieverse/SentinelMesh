VIDEO SCRIPT — SentinelMesh (90s)

0:00-0:05 — Opening
Visual: Close-up of phone with message notification.
VO: "Love shouldn't cost you everything."

0:05-0:18 — Problem
Visual: Montage of lonely users, chat screenshots, headline text.
VO: "Romance scams and social engineering cause billions in losses every year."

0:18-0:40 — Solution intro
Visual: SentinelMesh logo animation.
VO: "Meet SentinelMesh — an agentic AI system that detects and explains fraud in real-time."

0:40-0:60 — Live demo (screen capture)
Visual: User pastes a suspicious message → agents run → UI shows 'High Risk' with rationale and PDF report link.
VO: "Our multi-agent pipeline identifies red flags, reconstructs timelines, and generates a court-ready evidence pack."

0:60-0:80 — Tooling showcase
Visual: Quick cuts: Kiro agent spec, Q CLI generating endpoint, Q in VS Code fixing test.
VO: "Built and iterated using Amazon Kiro and Amazon Q Developer — from spec to working code faster than ever."

0:80-0:90 — Call to action
Visual: URL + GitHub repo.
VO: "Protect your community. Try SentinelMesh. Link in the description."
