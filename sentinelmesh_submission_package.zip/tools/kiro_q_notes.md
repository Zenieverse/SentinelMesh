Kiro & Amazon Q Developer Notes

1. Kiro:
   - Define agent specs per agents/agent_spec.md
   - Use Kiro to auto-generate agent glue code (export to Python)

2. Amazon Q Developer CLI:
   - q init
   - q generate api /ingest --lang python --framework fastapi
   - q test --generate

3. Amazon Q in IDE:
   - Use Q suggestions to refactor detection logic, create unit tests, and improve docs.