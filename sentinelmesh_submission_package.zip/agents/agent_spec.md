# SentinelMesh — Agent Specification (Kiro-ready)

## Overview
A pipeline of specialized agents to process suspicious inputs (text, screenshots, voice transcripts).

## Agents
1. IngestionAgent
   - Inputs: raw_text, metadata, attachments
   - Tasks: normalize text, OCR for images, transcribe audio
   - Outputs: normalized_record

2. DetectionAgent
   - Inputs: normalized_record
   - Tasks:
     - Run vector similarity against scam corpus
     - Run LLM-based prompt to score likelihood (0-1)
     - Apply rule-based heuristics (fast love-bombing, request-for-money patterns)
   - Outputs: detection_score, flags, rationale

3. ForensicsAgent
   - Inputs: normalized_record, flags
   - Tasks:
     - Extract entities (names, accounts, locations)
     - Timeline reconstruction
     - Reverse image search pointers (urls)
   - Outputs: forensic_bundle (json)

4. EvidenceAgent
   - Inputs: forensic_bundle, detection_score
   - Tasks:
     - Generate human-readable PDF with summary, timeline, evidence
     - Create JSON report for API consumers
   - Outputs: pdf_url, report_json

5. NotifierAgent
   - Inputs: report_json
   - Tasks:
     - Send alerts (email/webhook)
     - Offer user actions (block, report, seek help)
   - Outputs: notification_status

## Orchestration Flow (Kiro)
- User submits suspected message -> IngestionAgent -> DetectionAgent (parallel: vector + prompt)
- If detection_score > threshold -> ForensicsAgent -> EvidenceAgent -> NotifierAgent
- All steps log to local DB and emit trace IDs for audit
