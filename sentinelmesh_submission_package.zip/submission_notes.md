SentinelMesh Submission Notes

Include:
- README.md
- architecture.pdf
- agents/agent_spec.md
- video_script.md
- assets/logo.png and logo.svg
- demo backend (FastAPI stub)
- Add demo video to assets/video_demo.mp4 (record your screen)
- Add Q & Kiro screenshots into assets/